import random, time

class JarvisFactory():
    def __init__(self):
        self.producers  = {'Water Extractor': {'Materials':['Water'],'Rate':120},
                          'Oil Extractor'  : {'Materials':['Crude Oil'],'Rate':120},
                          'Miner Mk.3'  : {'Materials':['Iron Ore',
                                                           'Copper Ore',
                                                           'Limestone',
                                                           'Coal',
                                                           'Caterium Ore',
                                                           'Raw Quartz',
                                                           'Sulfur',
                                                           'Uranium',
                                                           'Bauxite',
                                                           'S.A.M Ore'],'Rate':240}
                          }

        self.converters = {'Smelter'        : 4 ,
                           'Packager'       : 10,
                           'Foundry'        : 16,  

                           'Constructor'    : 4 ,
                           'Assembler'      : 15,
                           'Refinery'       : 30,
                           'Manufacturer'   : 55}

        self.recipes = {converter:[] for converter in self.converters}

        for converter in self.converters:
            
            raw_recipes  = [line for line in open(converter+'.txt','r').read().replace('\n','\t').replace('alt ','').split('\t')]
            recipe = []
            
            for i in range(len(raw_recipes)):
                
                if 'x ' in raw_recipes[i]:
                    cut_recipes = raw_recipes[i].split('x  ')[1].replace('/min','')
                    material = ''.join([letter         for letter in cut_recipes        if not(letter.isnumeric())])
                    rate     = ''.join([cut_recipes[l] for l in range(len(cut_recipes)) if cut_recipes[l].isnumeric() or (cut_recipes[l] == '.' and cut_recipes[l-1].isnumeric())])
                    if material[-1] == '.': material = material[:-1]
                    recipe.append({'Material':material,'Rate':float(rate)})
            
                elif raw_recipes[i].isnumeric():
                    if len(recipe)>0: self.recipes[converter].append(recipe)
                    recipe = []

        listedMats = []
        mats = open('List of product names.txt','w+')
        for i in ['Iron Ore',
                                                           'Copper Ore',
                                                           'Limestone',
                                                           'Coal',
                                                           'Caterium Ore',
                                                           'Raw Quartz',
                                                           'Sulfur',
                                                           'Uranium',
                                                           'Bauxite',
                                                           'S.A.M Ore']:
            mats.write(i+'\n')
        for i in self.recipes:
            for q in self.recipes[i]:
                for k in q:
                    if k['Material'] not in listedMats:
                        listedMats.append(k['Material'])
                        mats.write(k['Material']+'\n')
        mats.close()


    def calculateCosts(self, product, rate, prevproduct='What You Wanted', depth=0, method='', raw_list=''):
        
        options  = []
        possible = []
        
        for i in self.producers:
            if product in self.producers[i]['Materials']:
                method.append(['\n','Recipe to produce:',product,'(Required to produce',prevproduct+')\n',
                              '-->',str(self.producers[i]['Rate'])+'x '+product,depth])
                method.append(['\n', 'For this you will need',
                               round(rate/self.producers[i]['Rate'],2),i.replace('or','ors').replace('3','3s'),'to extract:',
                               '\n',str(rate)+'x',product,'per minuite\n',depth])

                raw_list[product] += int(rate)+1
                return raw_list, method
                
        for c in self.recipes:
            for r in range(len(self.recipes[c])):
                if self.recipes[c][r][-1]['Material'] == product:
                    possible.append([])
                    
                    possible[-1].append(['\n','Recipe to produce:',product,'(Required to produce',prevproduct+')\n\n',
                                  ' + '.join([str(self.recipes[c][r][reactant]['Rate'])+'x '+self.recipes[c][r][reactant]['Material'] for reactant in range(len(self.recipes[c][r])-1)]),
                                  '-->',str(self.recipes[c][r][-1]['Rate'])+'x '+self.recipes[c][r][-1]['Material'],depth])

                    scale_factor = round(rate/self.recipes[c][r][-1]['Rate'], 2)
                    requirements = [[self.recipes[c][r][reactant]['Material'], round(scale_factor * self.recipes[c][r][reactant]['Rate'], 2)] for reactant in range(len(self.recipes[c][r])-1)]

                    possible[-1].append(['\n', 'For this you will need',
                                  scale_factor,c.replace('er','ers').replace('sy','ies').replace('or','ors'),'to convert:',
                                  '\n   ',('    ').join([str(requirements[reactant][1])+'x '+self.recipes[c][r][reactant]['Material']+'\n' for reactant in range(len(self.recipes[c][r])-1)]),
                                  'Into',str(rate)+'x',product,'per minuite\n',depth])

                    options.append(requirements)


        else:
            choice = random.randint(0,len(options)-1)
            requirements =  options[choice]
            method      += possible[choice]
            #for requirements in options:
            if prevproduct == 'What You Wanted': prevproduct = product
            else:                             prevproduct = product + ' --> ' + prevproduct
            for product, rate in requirements:
                raw_list, method = self.calculateCosts(product, rate, prevproduct=prevproduct, depth=depth+1, method=method, raw_list=raw_list)

        return raw_list, method

    def planFactory(self, component, rate, txtSave = True,
                    maximum = {'Water':9999, 'Crude Oil':9999, 'Iron Ore':9999, 'Copper Ore':9999, 'Limestone':9999, 'Coal':9999,
                               'Caterium Ore':9999, 'Raw Quartz':9999, 'Sulfur':9999, 'Uranium':9999, 'Bauxite':9999, 'S.A.M Ore':9999}):

        if txtSave: recipeTXT = open('Recipe for '+component+'.txt','w+')
        
        print('Options to produce',component,'at a rate of',rate,'per minute: (Using raw materials given)')
        options   = []
        iterations = 0
        start = time.time()

        while True:
            x, y = self.calculateCosts(component, rate,
                                  method   = [],
                                  raw_list = {'Water':0, 'Crude Oil':0, 'Iron Ore':0, 'Copper Ore':0, 'Limestone':0, 'Coal':0, 'Caterium Ore':0, 'Raw Quartz':0, 'Sulfur':0, 'Uranium':0, 'Bauxite':0, 'S.A.M Ore':0})
              
            for i in x:
                if x[i]>maximum[i]: break
            else:
                iterations += 1
                if x not in [x for x,y in options]:
                    options.append([x, y])
                    print('\nOption',str(len(options)-1)+':\n - ',
                          '\n - '.join([i+': '+str(x[i]) for i in x if x[i] != 0]),
                          '\nTotal:', sum([x[amount] for amount in x]))

                if iterations>5 or time.time() - start > 10: break #ideally I'd have a system to determine which options are worth showing or not.

            

        i = input('\nWhich is best, or generate new options? ')
        if not i.isnumeric():
            print('Okay, generating new options...\n') #instead I'll just do this
            self.planFactory(component, rate, maximum = maximum)
            return
        else:
            i = int(i)
        
        raw_list, method = options[i][0], options[i][1]
        depth = 0
        while True:
            printed = False
            for step in method:
                if step[-1]==depth:
                    printed = True
                    if txtSave: recipeTXT.write('\n'+' '.join([str(i) for i in step[:-1]]))
                    else: print(' '.join([str(i) for i in step[:-1]]))

            if txtSave: recipeTXT.write('\n'+'='*200+'\n')
            else: print('='*200)
            depth += 1
            if not(printed): break

        if txtSave: print('Recipe saved to:','Recipe for '+component+'.txt')
            

component = 'Modular Frame' #acceptable component names are listed in: List of product names.txt
rate  = 30 #per min
maximum   = {'Water':0, 'Crude Oil':0, 'Iron Ore':500, 'Copper Ore':500, 'Limestone':0, 'Coal':0, 'Caterium Ore':0, 'Raw Quartz':0, 'Sulfur':0, 'Uranium':0, 'Bauxite':0, 'S.A.M Ore':0}


Factory = JarvisFactory()
Factory.planFactory(component, rate, maximum = maximum)
