import pyaudio, numpy as np, matplotlib.pyplot as plt, winsound, simpleaudio as sa, time, urllib.request, webbrowser
from pynput.keyboard import Key, Controller
from multiprocessing import Process
from collections import Counter
from bs4 import BeautifulSoup
keyboard = Controller()

major=[1, 3, 5, 6, 8, 10, 12, 13, 15, 17, 18, 20, 22, 24, 25, 27, 29, 30, 32, 34, 36, 37, 39, 41, 42, 44, 46, 48, 49, 51, 53, 54, 56,
       58, 60, 61, 63, 65, 66, 68, 70, 72, 73, 75, 77, 78, 80, 82, 84, 85, 87, 89, 90, 92, 94, 96, 97, 99, 101, 102, 104, 106, 108]
minor=[1, 3, 4, 6, 8, 9, 11, 13, 15, 16, 18, 20, 21, 23, 25, 27, 28, 30, 32, 33, 35, 37, 39, 40, 42, 44, 45, 47, 49, 51, 52, 54, 56,
       57, 59, 61, 63, 64, 66, 68, 69, 71, 73, 75, 76, 78, 80, 81, 83, 85, 87, 88, 90, 92, 93, 95, 97, 99, 100, 102, 104, 105, 107]

scales=['C','Cm', 'Db','Dbm', 'D','Dm', 'Eb','Ebm', 'E','Em', 'F','Fm', 'F#','F#m',
        'G','Gm', 'Ab','Abm', 'A','Am', 'B','Bm','Bb','Bbm']

all_scales=[]
for i in range(12):
    all_scales.append([])
    for note in major: all_scales[-1].append(note+i-1)
    all_scales.append([])
    for note in minor: all_scales[-1].append(note+i-1)

def get_scale():
    close=[]
    common=[0]*24
    for scale in all_scales:
        off=0
        for note in all_notes:
            common[(note%12)*2]+=1/24
            common[(note%12)*2+1]+=1/24
            if note not in scale: off+=1
        close.append(off)
        
    for i in range(len(common)): common[i]=round(common[i])
    mini=close[0],0
    for i in range(1,len(close)):
        if close[i]<mini[0]: mini=close[i],i
        elif close[i]==mini[0] and common[i]>common[mini[1]]:
            mini=close[i],i

    print('Guess Scale =',scales[mini[1]],'\n')

CHUNK = 4096 
RATE = 200000
pa       = pyaudio.PyAudio()
FORMAT   = pyaudio.paInt16
CHANNELS = 1

#should work but if it dosent you can set the index manually
for ii in range(pa.get_device_count()):
   if 'VoiceMeeter Output' in pa.get_device_info_by_index(ii)['name']:
       index = ii
       break

stream = pa.open(format = FORMAT,
                 channels = CHANNELS,
                 rate = RATE,
                 input = True,
                 input_device_index = index,
                 frames_per_buffer = CHUNK)

freqs=[0]*3
samples=[]
all_notes=[]
note=True

convert=open('converter.txt','r').read().split('\n')
for i in range(len(convert)): convert[i]=convert[i].split('\t')

scale_got = False
start = time.time()
for i in range(99999999999): #I HAVE NO IDEA WHY I CAN'T USE A WHILE TRUE HERE, BUT IT WON'T WORK IF I DO
    data = np.frombuffer(stream.read(CHUNK),dtype=np.int16)
    data = data * np.hanning(len(data))

    fft = abs(np.fft.fft(data).real)
    fft = fft[:int(len(fft)/2)]

    freq = np.fft.fftfreq(CHUNK,1.0/RATE)
    freq = freq[:int(len(freq)/2)]

    freqPeak = freq[np.where(fft==np.max(fft))[0][0]]+1

    val = fft[np.where(freq>freqPeak)[0][0]]
    
    #print('-'*int(val/10000))
    if int(val/5000)>10:
        
        freqs[i%len(freqs)] = freqPeak
        if freqs[1:] == freqs[:-1] and note:

            mindiff=99999,0
            for q in freqs:
                for i in convert:
                    diff=abs(q-float(i[1]))
                    if diff<mindiff[0]: mindiff=diff,i,q

            if mindiff[0]<15:
                print('-'*int(val/20000),mindiff[1][0])
                samples.append(mindiff[1][1])
                note=False

        else: note=True
    else:
        if samples!=[]:
            c = Counter(samples)
            for i in range(len(convert)):
                if c.most_common(1)[0][0] in convert[i]:
                    
                    all_notes.append(i)
                    break
        samples=[]
    if int(time.time() - start) % 5 == 0:
        if not scale_got:
            scale_got = True
            get_scale()
    else:
        scale_got = False
    
stream.stop_stream()
stream.close()
p.terminate()
