<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/x-icon" href="/include/favicon.ico" />
    <link rel="stylesheet" href="/include/styles.css" />
    <style>
    :root { --theme: rgb(102, 0, 255); }
    </style>
</head>
<body onload="hideSlider()">

<canvas id="canv" position="absolute"></canvas>

<div id="MenuBar" onmousemove="moveSlider(event)" onmouseleave="hideSlider()">
    <a href="/"> 
        <img id="logo" src="/include/logo.png" width="100%" style="position: absolute; top: 10px; left: 2%"></img>
        <img id="logohover" width="100%" style="position: absolute; top: 10px; left: 2%"></img> 
    </a>
    <div id="Highlight"></div>
    <div id="Slider"></div>

    <a href="javascript:getBackURL()"> <div class="Option" style="top: 130px">Back</div></a>

    <?php
    error_reporting(E_ALL ^ E_NOTICE);  
    $dir = isset($_GET["url"]) ? urldecode($_GET["url"].'/') : '';

    $folders = glob($dir.'*');
    $top = 130;
    for ($i=0; $i < count($folders); $i++) {
        if (!str_contains($folders[$i], '.') && $folders[$i] != "include") {
            $top += 60;
            echo '<div class="Option" style="top: '.$top.'px" 
                onclick=
                "document.location = document.location.href.split(\'?\')[0] + \'?&url=\' + (document.location.href.split(\'&url=\')[1] ? document.location.href.split(\'&url=\')[1] + \'/\' : \'\') + this.innerHTML"
                >'.end(explode("/", $folders[$i])).'</div>';
        }
    }
    ?>
    
</div>

<div id="PageInfo">
    <?php 
        $count = 0;
        $html  = glob($dir.'*.html');
        $img   = array_merge(glob($dir.'*.jpg'), glob($dir.'*.png'), glob($dir.'*.gif'));
        $vid   = array_merge(glob($dir.'*.mp4'), glob($dir.'*.ogg'));
        $pdf   = glob($dir.'*.pdf');
        $txt   = glob($dir.'*.txt');
        $all   = array_merge($html, $img, $vid, $pdf, $txt);
        $other = glob($dir.'*.*');

        for ($i=0; $i < count($html); $i++) {
            $count += 1;
            echo '<div class="InfoBox">
                '.file_get_contents($html[$i]).'
            </div>';

        } for ($i=0; $i < count($img); $i++) {
            $count += 1;
            echo '<div class="InfoBox">
                <h1>'.end(explode("/", substr($img[$i], 0, -4))).'</h1>
                <img id="image" src="'.$img[$i].'" onclick="window.open('."'".$img[$i]."'".')"></img>
            </div>';

        } for ($i=0; $i < count($vid); $i++) {
            $count += 1;
            echo '<div class="InfoBox">
                <h1>'.end(explode("/", substr($vid[$i], 0, -4))).'</h1>
                <video width="355" height="200" controls> <source src="'.$vid[$i].'"></video>
            </div>';

        } for ($i=0; $i < count($pdf); $i++) {
            echo '<div class="InfoBox">
                <h1>'.end(explode("/", substr($pdf[$i], 0, -4))).'</h1>
                <a onclick="window.open('."'".$pdf[$i]."'".')">Open in new tab</a><br>
                <a onclick="togglePDF('.$count.')">Open below</a><br>
                <embed id="pdf" src="'.$pdf[$i].'"></embed>
            </div>';
            $count += 1;

        } for ($i=0; $i < count($txt); $i++) {
            $count += 1;
            echo '<div class="InfoBox">
                <h1>'.end(explode("/", substr($txt[$i], 0, -4))).'</h1>
                <p1 style="white-space: pre-line">'.file_get_contents($txt[$i]).'</p1>
            </div>';
        } for ($i=0; $i < count($other); $i++) {
            if (!in_array($other[$i], $all) && !str_contains($other[$i], '.php')) {
                $count += 1;
                echo '<div class="InfoBox">
                    <h1><a id="copy" onclick="copyPath(\''.str_replace("\\", "\\\\", getcwd()).'\\\\'.str_replace("/", "\\\\", $other[$i]).'\')"><span>'.end(explode("/", $other[$i])).'</span></a></h1>
                </div>';
            }
        }
    ?>
</div>

<div id="HideContents" onclick="toggleContents()">&lt;</div>

<div id="Contents"> <h1 id="text">Contents:</h1><p1 id="text">Click to jump to chapter:<br><wbr></p1> </div>

<script  src="/include/scripts.js"></script>
</body>

</html>