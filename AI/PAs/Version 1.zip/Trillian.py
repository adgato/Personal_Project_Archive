from pygame import mixer
mixer.init()

import time, webbrowser, datetime, sys, wikipedia, random, urllib.request, geocoder, lxml, requests, turtle, socket, os, inflect, warnings, gensim
from bs4 import BeautifulSoup
from pyowm import OWM
from nltk.tokenize import sent_tokenize, word_tokenize
from PyDictionary import PyDictionary
from nltk.corpus import wordnet as wn
from nltk.stem.wordnet import WordNetLemmatizer
from gensim.models import Word2Vec
import speech_recognition as sr
from gtts import gTTS
from pygame import mixer
from tempfile import TemporaryFile

playlist=['make your own, add file paths here']

p = inflect.engine()

mood=50
cities=['new york','tokyo','london'] #none of which are my home :)) 

dictionary=PyDictionary()
ignore=['int.',',',', ','exp.','adj.','n.','adv.','v.','idi.',]
pronouns=[['my','your','their','our','his','her','its','the'],['i','I','me','you','they','we','he','she','it']]
remove=['be','have','do','say','go','the']
good=[]
bad=[]

def voicebox(audioString, wait):
    tts = gTTS(text=audioString, lang='en-us')
    sf = TemporaryFile()
    tts.write_to_fp(sf)
    sf.seek(0)
    mixer.music.load(sf)
    mixer.music.play()
    print(audioString)
    time.sleep(wait)
    
#EITHER
def speak(string, n):             #for verbal output
    voicebox(string, len(string) / n)
#OR
#def speak(x,t): print(x)         #for text output

#EITHER
def ask(question, v):             #for verbal input
    r = sr.Recognizer()
    data = ''
    if v == 1:
        speak(question, 12)
        print('Speak:')
    else:
        print(question)
    while True:
        with sr.Microphone() as (source):
            audio = r.listen(source)
        try:
            answer = r.recognize_google(audio)
            print('Hold on...')
            break
        except sr.UnknownValueError:
            continue
        except sr.RequestError as e:
            try:
                continue
            finally:
                e = None
                del e

    return answer
#OR
def ask(x,t): return input(x+' ') #for verbal input


#def getWeather(location):
#    try:
#        city=location
#        owm = OWM(API_key='ab0d5e80e8dafb2cb81fa9e82431c1fa')
#        obs = owm.weather_at_place(city)
#        w = obs.get_weather()
#        k = w.get_status()
#        x = w.get_temperature(unit='celsius')
#        speak('In '+city+', it is '+str(x['temp'])+'°C and the forecast is '+k,9)
#    except Exception as e:
#        print(e)
#        speak('Yawn...',14)
#        global mood
#        mood-=10
#        return
def getJoke():
    res = requests.get('https://icanhazdadjoke.com/',headers={"Accept":"application/json"})
    if res.status_code == requests.codes.ok:
        speak(str(res.json()['joke']),13)
        mixer.music.play()
    else:
        speak('Yawn...',14)
        global mood
        mood-=10
def getNews(amount):
        news_url="https://news.google.com/news/rss"
        Client=urllib.request.urlopen(news_url)
        page=Client.read()
        Client.close()
        soup_page=BeautifulSoup(page,"xml")
        news_list=soup_page.findAll("item")
        news=amount
        speak('Say next for the next article or more for more on the article.',14)
        for news in news_list[:int(news)]:
              more=ask(news.title.text,1)
              if 'more' in more:
                webbrowser.open("https://www.google.com/search?q="+news.title.text)
                speak('I have opened the article on the web for you, have a nice look!',14)

def watchVid(search):
    resp = urllib.request.urlopen("https://www.youtube.com/results?search_query="+search.replace(' ','+'))
    soup = BeautifulSoup(resp, from_encoding=resp.info().get_param('charset'),features="html5lib")
    for link in soup.find_all('a', href=True):
        if '/watch?v=' in link['href']:
            video='https://www.youtube.com'+link['href']
            break
    webbrowser.open(video)
    speak('Please pardon the adverts',14)

def myMusic():
        choice='C:\AdamC\Music'+random.choice(playlist)
        mixer.music.load(choice)
        mixer.music.play()
        paused=False
        while True:
            print('Playing '+choice)
            controller=ask('Say: pause, unpause, skip, next, stop ',0)
            if 'pause' in controller:
                if paused:
                    mixer.music.unpause()
                    paused=False
                else:
                    mixer.music.pause()
                    paused=True
            elif controller=='skip' or controller=='next':
                choice=random.choice(playlist)
                mixer.music.load(choice)
                mixer.music.play()
            elif controller=='stop': break
            else: print(controller+' is an unknown command...')
        mixer.music.fadeout(1500)
        speak("I'm glad to have my voice back!",14)

def ipTrack(ip):
    try:
        location= geocoder.ip(ip)
        location= location.latlng
        location=str(location[0])+','+str(location[1])
        webbrowser.open("https://earth.google.com/web/search/" + str(location))
        speak('The ip is close to '+geocoder.ip(ip).city,14)
    except TypeError:
        speak('The IP you entered is not a valid ip adress',14)

def ping(ip):
    sock=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bytes = random._urandom(65000)
    duration= ''
    while not(duration.isnumeric()):
            duration=ask('For how long?',1)
            if not(duration.isnumeric()): speak(duration+' is not a number',14)
    timeout = time.time() + int(duration)
    print('Pinging '+ip+'...')
    while True:
        if time.time() > timeout: break
        sock.sendto(bytes,(ip,8080))
    speak('Pinged!',14)

def PAS(command):
 if 'sidon' in command or 'si' in command or 'Sydenham' in command: #bad speech detection
     subject=ask('Which subject can I help you revise?',1)
     bank=open(subject+'.txt','r')
     search=ask('What would you like to know everything about? ',1)
     for i in bank.readlines():
         if search in i: speak(i,13)

 elif 'trillian' in command or 'trill' in command or 'brilliant' in command or 'Trillium' in command: #primitive NLP I created
        print('you can ask if trillian likes something by saying do you like THING, or ask anything else to her')
        state=ask('Whats up?',1)
        if 'do you like' in state:
            subject=state.replace("do you like ",'')
            remember=open("likes.txt",'r')
            lineno=0
            for line in remember.readlines():
                lineno+=1
                if subject in line:
                    speak('I remember learning that '+str(line),14)
                    if not('yes' in ask('Would you like me to reasses my previous judgement? ',1)): return
                    else:
                        speak('First remove line '+str(lineno)+" from the file likes.txt",7)
                        ask('Ready to proceed?',1)
            try:
                def idea(subject):
                    style=ask('Do you want a hasty judgement or an accurate yet slow judgement? ',1)
                    if 'accurate' in style or 'a' in style: count=-999999999
                    else: count=0
                    topic = wikipedia.page(subject)
                    data=[]
                    for i in sent_tokenize((topic.content.encode('utf-8')).decode()):
                        if count>20: break
                        count+=1
                        temp = []
                        leni=len(word_tokenize(i))
                        for j in range(leni): temp.append(word_tokenize(i)[j].lower())
                        if str(temp)!='[]':
                            lentemp=len(temp)
                            for i in range(lentemp):
                                if temp[i] in good: temp.append('good')
                                if temp[i] in bad: temp.append('bad')
                            data.append(temp) 
                    relate = gensim.models.Word2Vec(data, min_count = 1, size = 100, window = 5, sg = 1)
                    ops=[]
                    sops=[]
                    for i in data:
                        opin=0
                        sent=''
                        cont=True
                        if subject in i:
                                for j in i:
                                    if j=='good': opin+=1
                                    elif j=='bad': opin-=1
                                    else:
                                        if j[0]=='.': cont=False
                                        if cont: sent+=j+' '
                                        if j[len(j)-1]=='.': cont=False
                                ops.append(opin)
                                sops.append(sent)
                    relate = gensim.models.Word2Vec(data, min_count = 1, size = 100, window = 5, sg = 1)
                    record = open("likes.txt",'a')
                    try:
                        if relate.wv.similarity(subject, 'good')>relate.wv.similarity(subject, 'bad'):
                            speak('Yes, I like '+str(subject)+' BECAUSE '+str(sent_tokenize(sops[ops.index(max(ops))])[0]),11)
                            record.write(str(subject)+' is good\n')
                        else:
                            speak("No, I don't like "+str(subject)+' BECAUSE '+str(sent_tokenize(sops[ops.index(min(ops))])[0]),11)
                            record.write(str(subject)+' is bad\n')
                    except Exception as e: speak(e,14)
                    record.close()
                idea(subject)
            except Exception as e:
                a=str(e).split('\n')
                speak('Did you mean '+', '.join(a[1:]),14)
                subject=input(subject+' not found, please choose one of the above ')
                idea(subject)
                
        else:
            search = word_tokenize(state)
            nxwd=''
            subj=''
            ourpro=''
            theme='neu'
            lenbigdef=0
            goode=0
            bade=0
            for i in bad:
                if i in search:
                    bade+=1
                    if WordNetLemmatizer().lemmatize(i,'v')!=i: be='past'
                    else: be='present'
                    state=state.replace(i,'')
            for i in good:
                if i in search:
                    goode+=1
                    if WordNetLemmatizer().lemmatize(i,'v')!=i: be='past'
                    else: be='present'
                    state=state.replace(i,'')
            if goode>=bade: theme='good'
            else: theme='bad'
            for word in search:
                if word in pronouns[0] or word in pronouns[1]: state=state.replace(word+' ','')
                for pronoun in range(len(pronouns[0])):            
                    if word == pronouns[0][pronoun]:
                        ourpro=pronouns[0][pronoun]
                        if ourpro=='my': ourpro='your'
                        elif ourpro=='your': ourpro='my'
                        nxwd='possess'
                if WordNetLemmatizer().lemmatize(word,'v')=='be': be=word
                if WordNetLemmatizer().lemmatize(word,'v') in remove: state=state.replace(word,'')
            subj=state
            plural=word_tokenize(subj)
            try:
                if len(plural[len(plural)-1])>len(p.plural(plural[len(plural)-1])):
                    if be=='past': be='were'
                    else: be='are'
                else:
                    if be=='past': be='was'
                    else: be='is'
                sentence=str(ourpro+' '+subj+' '+be+' '+theme)
                removespace=word_tokenize(sentence)
                sentence=''
                for i in removespace:
                    sentence+=i+' '
                speak(sentence,14)
                record = open("likes.txt",'r')
                lineno=0
                for line in record.readlines():
                    lineno+=1
                    if ourpro.replace(' ','')+' '+subj.replace(' ','') in line:
                        speak('Wait, I remember learning that '+str(line),14)
                        if not('yes' in ask('Would you like me to reasses my previous judgement? ',1)):
                            speak('Sure thing',14)
                            return
                        else:
                            speak('First remove line '+str(lineno)+" from the file likes.txt",7)
                            ask('Ready to proceed?',1)      
                record = open("likes.txt",'a')
                record.write(sentence+'\n')
                record.close()
            
            except Exception as e:
                print(e)
                speak("Sorry, I don't understand the phrase "+str(subj),14)
                
 elif 'compass' in command or 'compas' in command or 'Converse' in command: #novel features
    command=ask('How can I help?',1)
    if "what time is it" in command:
        timestamp=str(datetime.datetime.now().time())
        if timestamp[0]!='0':mins=timestamp[3]+timestamp[4]
        else: mins=timestamp[4]
        if timestamp[0]!='0':hour=timestamp[0]+timestamp[1]
        else: hour=timestamp[1]
        if int(hour)>12: hour=int(hour)-12
        speak('It is '+mins+' past '+str(hour),9)

    elif 'locate ip' in command or 'locate IP' in command:
        ip=''
        for i in range(len(command)):
            if 'locate ip' in command:
                if i>8: ip+=command[i]
            else:
                if i>9: ip+=command[i]
            ip = ip.replace(' ', '')
        ipTrack(ip)

    elif 'ping ip' in command or 'ping IP' in command:
        ip=''
        for i in range(len(command)):
            if 'ping ip' in command:
                if i>6: ip+=command[i]
            else:
                if i>7: ip+=command[i]
            ip = ip.replace(' ', '')
        ping(ip)

    elif 'directions to' in command:
        location=''
        for i in range(len(command)):
            if i>13: location+=command[i]
        webbrowser.open("https://www.google.com/maps/dir/my+location/" + location)
        speak('Directions are open',14)
    elif 'where am I' in command:
        webbrowser.open("https://www.google.com/maps?q=my+location")
        speak('Here you are:',14)
    elif "where is" in command:
        location=''
        for i in range(len(command)):
            if i>8: location+=command[i]
        webbrowser.open("https://earth.google.com/web/search/" + location)
        speak("Here is " + location+':',13)


    elif 'music' in command:
        speak('I will be quiet for you now, please read my text instead.',14)
        myMusic()
        
    elif 'play' in command:
        search=''
        for i in range(len(command)):
            if i>4: search+=command[i]
        speak("Playing " +search,14)
        if 'revision tracks' in search: webbrowser.open('https://www.youtube.com/playlist?list=PLeJkY50HY7q6jnvzVuFybEmgXJB0IYurn')
        else: watchVid(search)

    elif 'joke' in command:
        getJoke()

    elif 'shut down' in command or 'quit' in command:
        speak('Goodbye, have a nice day',14)
        sys.exit()

    elif 'tell me about' in command:
        subject=''
        tsentence=''
        while not(tsentence.isnumeric()):
            tsentence=ask('How many sentences?',1)
            if not(tsentence.isnumeric()): speak(tsentence+' is not a number',14)
        sentences=0
        for i in range(len(command)):
            if i>13: subject+=command[i]
        speak('Have patience Sir, this may take a while.',14)
        topic = wikipedia.page(subject)
        for i in range (len((topic.content.encode('utf-8')).decode())):
            if (topic.content[i].encode('utf-8')).decode() == '.': sentences+=1
            if sentences==int(tsentence):
                length=i
                break
        speak((topic.content[:length+1].encode('utf-8')).decode(),10)
        speak('That is enough for now',14)

    elif 'how do you spell' in command:
        word=''
        for i in range(len(command)):
            if i>16 and command[i]!=' ': word+=command[i]
        speak(word+':',14)
        word=list(word.upper())
        for w in word: speak(w,20)

    #elif 'get weather for' in command:
    #    city=''
    #    for i in range(len(command)):
    #        if i>15: city+=command[i]
    #    getWeather(city)

    elif 'news' in command:
        news=''
        while not(news.isnumeric()):
            news=ask('How many articles Sir?',1)
            if not(news.isnumeric()): speak(news+' is not a number',14)
        getNews(news)

    elif 'calculate' in command:
        maths=command.replace('calculate','')
        math=maths
        while 'x' in math: math=math.replace('x','*')
        speak(maths+' = '+str(eval(math)),9)
        
    elif 'graph' in command:
        graph=''
        graphcor=[]
        while not(graph.isnumeric()):
            graph=ask('And what will the Y co-ordinates be? (When each co-ordinate must be one digit long)',1)
            graph=graph.replace(' ','')
            if not(graph.isnumeric()) or len(graph)<2: speak(graph+' is not a string of Y co-ordinates',14)
        for i in graph: graphcor.append(int(i))
        maximum=1000/max(graphcor)
        xgap=1900/(len(graphcor)-1)
        line=turtle.Turtle()
        line.penup()
        line.goto(-950,graphcor[0]*maximum-500)
        line.pendown()
        for i in range(len(graphcor)):
            if i!=0: line.goto(line.xcor()+xgap,graphcor[i]*maximum-500)
        time.sleep(3)
        del line
        turtle.clearscreen()
        turtle.bye()
        speak("I don't know about you, but that's enough graph for me.",14)

    elif 'search' in command:
        url=''
        for i in range(len(command)):
            if i>6: url+=command[i]
        webbrowser.open("https://www.google.com/search?q="+url)
        speak('I have searched '+url+' for you',14)

    elif 'pass'==command: pass
    
    elif len(command)>0: speak(command+' is an unknown command..., commands are\n',9)
    print('\n'.join(['what time is it','search QUERY','graph','calculate EQUATION' ,'news','how do you spell WORD','tell me about SOMETHING','shut down','joke''play VIDEO','music',"where is PLACE",
                     'where am I','directions to PLACE','ping ip IP ADDRESS','locate ip IP ADDRESS']))
 else: speak(command+' is an unknown command..., say sidon, trillian or compass',9)
#main
while True:
    asks=['So, what will it be?','Awaiting further instructions','I am of mood '+str(mood),'What would you like me to do for you?']
    tired=False
    #29/08/21 pyOWM has updated, the code below doesn't work
    #owm = OWM(API_key='API_KEY')
    #obs = owm.weather_at_place('london')
    #w = obs.get_weather()
    #k = w.get_status()
    #if k=='Rain': mood-=10
    #if not(tired) and mood>0:
    #    if random.randint(0,3)==1: getWeather(random.choice(cities))
    #    elif random.randint(0,1)==1: getJoke()
    PAS(ask(random.choice(asks),1))
    
        
