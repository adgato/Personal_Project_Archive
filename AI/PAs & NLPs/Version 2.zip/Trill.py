import os, random, discord, time, webbrowser, datetime, sys, wikipedia, random, urllib.request, geocoder, lxml, requests, turtle, socket, os, inflect, warnings, gensim, nltk, random_sentence
from multiprocessing import Process
from dotenv import load_dotenv
from discord.ext import commands
from urllib.request import urlopen, Request, urlopen
from bs4 import BeautifulSoup
from pyowm import OWM
from nltk.tokenize import sent_tokenize, word_tokenize
from PyDictionary import PyDictionary
from nltk.corpus import wordnet as wn
from nltk.stem.wordnet import WordNetLemmatizer
from gensim.models import Word2Vec

TOKEN = 'TOKEN'
load_dotenv()
bot = commands.Bot(command_prefix='-')
bot.remove_command('help')

def inputs(): import Input.py



@bot.event
async def on_ready():
    print(f'{bot.user.name} has connected to Discord!')

@bot.command(name='toupper')
async def toupper(ctx):
#INPUT
    inputt = open('input.txt','r').read()
    await ctx.send('Input please')
    time.sleep(0.5)
    while inputt==open('input.txt','r').read(): pass
    inputt = open('input.txt','r').read()
#
    await ctx.send(str(inputt).upper())

@bot.command(name='tolower')
async def tolower(ctx):
#INPUT
    inputt = open('input.txt','r').read()
    await ctx.send('Input please')
    time.sleep(0.5)
    while inputt==open('input.txt','r').read(): pass
    inputt = open('input.txt','r').read()
#
    await ctx.send(str(inputt).lower())

@bot.command(name='idle')
async def idle(ctx):
    await ctx.send('Please @ '+str(ctx.author)[:-5]+' if you want to get their attention, they are doing something else now.')

@bot.command(name='working')
async def idle(ctx, method):
    if method == 'willingly': await ctx.send('Please don\'t @ '+str(ctx.author)[:-5]+' to distract them, as they are working and would like to finish their work now :)')
    else: await ctx.send('Feel free to @ '+str(ctx.author)[:-5]+' to distract them, as they are working and they don\'t want to be.')

@bot.command(name='goodbye')
async def goodbye(ctx):
    await ctx.send(str(ctx.author)[:-5]+" is closing Discord now, don't disturb them unless you think they would want to be disturbed.")
    await ctx.send('Goodbye '+str(ctx.author)[:-5]+'!')

@bot.command(name='back')
async def back(ctx):
    await ctx.send(str(ctx.author)[:-5]+' is back from whatever they were doing.')


@bot.command(name='help')
async def help(ctx):
    await ctx.send('''```diff
Commands:
-help
-toupper
-tolower
-idle
-working (willingly / unwillingly)
-goodbye
-back
-members
-directions-to (location)
-forecast (location)
-ramble (subject)
-joke
-meme
-inspire-me
-news
-what-is (word)
-rank
-gamble (odds)
```''')



@bot.command(name='directions-to')
async def location(ctx, location):
    await ctx.send("https://www.google.com/maps/dir/my+location/" + location)
    await ctx.send('Directions are open')

@bot.command(name='forecast')
async def getWeather(ctx, arg):
    try:
        city=arg
        owm = OWM(API_key='ab0d5e80e8dafb2cb81fa9e82431c1fa')
        obs = owm.weather_at_place(city)
        w = obs.get_weather()
        k = w.get_status()
        x = w.get_temperature(unit='celsius')
        await ctx.send('In '+city+', it is '+str(x['temp'])+'°C and the forecast is '+k)
    except Exception as e:
        await ctx.send('Error, unable to get weather, please try again.')
        print(e)

@bot.command(name='joke')
async def joke(ctx):
    res = requests.get('https://icanhazdadjoke.com/',headers={"Accept":"application/json"})
    if res.status_code == requests.codes.ok:
        await ctx.send(str(res.json()['joke']))
    else:
        await ctx.send('Error, unable to get joke, please try again.')
        print(e)

@bot.command(name='meme')
async def meme(ctx):
    html = urlopen("https://meme-api.herokuapp.com/gimme")
    false=False
    meme=eval(html.read())['url']
    await ctx.send(meme)

@bot.command(name='inspire-me')
async def inspire(ctx):
    quotes=["Success is most often achieved by those who don't know that failure is inevitable.","Things work out best for those who make the best of how things work out.","Courage is grace under pressure.","If you are not willing to risk the usual, you will have to settle for the ordinary.","Learn from yesterday, live for today, hope for tomorrow. The important thing is not to stop questioning.","Take up one idea. Make that one idea your life -- think of it, dream of it, live on that idea. Let the brain, muscles, nerves, every part of your body be full of that idea, and just leave every other idea alone. This is the way to success.","Sometimes you can't see yourself clearly until you see yourself through the eyes of others.","All our dreams can come true if we have the courage to pursue them.","It does not matter how slowly you go, so long as you do not stop.","Success is walking from failure to failure with no loss of enthusiasm.","Someone is sitting in the shade today because someone planted a tree a long time ago.","Whenever you see a successful person, you only see the public glories, never the private sacrifices to reach them.","Don't cry because it's over, smile because it happened.","Success? I don't know what that word means. I'm happy. But success, that goes back to what in somebody's eyes success means. For me, success is inner peace. That's a good day for me.","You only live once, but if you do it right, once is enough.","Opportunities don't happen. You create them.","Once you choose hope, anything's possible.","Try not to become a person of success, but rather try to become a person of value.","There is no easy walk to freedom anywhere, and many of us will have to pass through the valley of the shadow of death again and again before we reach the mountaintop of our desires.","It is not the strongest of the species that survive, nor the most intelligent, but the one most responsive to change.","The best and most beautiful things in the world cannot be seen or even touched -- they must be felt with the heart.","Great minds discuss ideas; average minds discuss events; small minds discuss people.","Live as if you were to die tomorrow. Learn as if you were to live forever.","The best revenge is massive success.","The difference between winning and losing is most often not quitting.","I have not failed. I've just found 10,000 ways that won't work.","When you cease to dream you cease to live.","A successful man is one who can lay a firm foundation with the bricks others have thrown at him.","May you live every day of your life.","No one can make you feel inferior without your consent.","Failure is another steppingstone to greatness.","The whole secret of a successful life is to find out what is one's destiny to do, and then do it.","If you're not stubborn, you'll give up on experiments too soon. And if you're not flexible, you'll pound your head against the wall and you won't see a different solution to a problem you're trying to solve.","If you're going through hell, keep going.","In order to be irreplaceable one must always be different.","What seems to us as bitter trials are often blessings in disguise.","You miss 100 percent of the shots you don't take.","The distance between insanity and genius is measured only by success.","The way I see it, if you want the rainbow, you gotta put up with the rain.","To me, business isn't about wearing suits or pleasing stockholders. It's about being true to yourself, your ideas and focusing on the essentials.","The longer I live, the more beautiful life becomes.","Happiness is a butterfly, which when pursued, is always beyond your grasp, but which, if you will sit down quietly, may alight upon you.","You must expect great things of yourself before you can do them.","If you can't explain it simply, you don't understand it well enough.","You can't please everyone, and you can't make everyone like you.","There are two types of people who will tell you that you cannot make a difference in this world: those who are afraid to try and those who are afraid you will succeed.","I believe every human has a finite number of heartbeats. I don't intend to waste any of mine.","Start where you are. Use what you have. Do what you can.","Don't limit yourself. Many people limit themselves to what they think they can do. You can go as far as your mind lets you. What you believe, remember, you can achieve.","People ask, 'What's the best role you've ever played?' The next one.","The two most important days in your life are the day you are born and the day you find out why.","I find that the harder I work, the more luck I seem to have.","It often requires more courage to dare to do right than to fear to do wrong.","Success is the sum of small efforts, repeated day-in and day-out.","As you grow older, you will discover that you have two hands, one for helping yourself, the other for helping others.","If you want to achieve excellence, you can get there today. As of this second, quit doing less-than-excellent work.","If your actions inspire others to dream more, learn more, do more, and become more, you are a leader.","All progress takes place outside the comfort zone.","The more you praise and celebrate your life, the more there is in life to celebrate.","You may only succeed if you desire succeeding; you may only fail if you do not mind failing.","A dream doesn't become reality through magic; it takes sweat, determination, and hard work.","Only put off until tomorrow what you are willing to die having left undone.","The biggest risk is not taking any risk... In a world that's changing really quickly, the only strategy that is guaranteed to fail is not taking risks.","We become what we think about most of the time, and that's the strangest secret.","Do one thing every day that scares you.","The only place where success comes before work is in the dictionary.","Don't be afraid to give up the good to go for the great.","Your work is going to fill a large part of your life, and the only way to be truly satisfied is to do what you believe is great work. And the only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle. As with all matters of the heart, you'll know when you find it.","Don't worry about failure; you only have to be right once.","Though no one can go back and make a brand-new start, anyone can start from now and make a brand-new ending.","Nothing great was ever achieved without enthusiasm.","Twenty years from now you will be more disappointed by the things that you didn't do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover.","Keep your face to the sunshine and you can never see the shadow.","The first step toward success is taken when you refuse to be a captive of the environment in which you first find yourself.","One of the greatest diseases is to be nobody to anybody.","Identity is a prison you can never escape, but the way to redeem your past is not to run from it, but to try to understand it, and use it as a foundation to grow.","The successful warrior is the average man, with laser-like focus.","Rarely have I seen a situation where doing less than the other guy is a good strategy.","If you always do what interests you, at least one person is pleased.","Keep on going, and the chances are that you will stumble on something, perhaps when you are least expecting it. I never heard of anyone ever stumbling on something sitting down.","I avoid looking forward or backward, and try to keep looking upward.","You can't connect the dots looking forward; you can only connect them looking backward. So you have to trust that the dots will somehow connect in your future. You have to trust in something -- your gut, destiny, life, karma, whatever. This approach has never let me down, and it has made all the difference in my life.","Life is short, and it is here to be lived.","Everything you can imagine is real.","Change will not come if we wait for some other person or some other time. We are the ones we've been waiting for. We are the change that we seek.","If you want to make a permanent change, stop focusing on the size of your problems and start focusing on the size of you!","Successful people do what unsuccessful people are not willing to do. Don't wish it were easier; wish you were better.","It is never too late to be what you might have been.","If you love what you do and are willing to do what it takes, it's within your reach. And it'll be worth every minute you spend alone at night, thinking and thinking about what it is you want to design or build.","In my experience, there is only one motivation, and that is desire. No reasons or principle contain it or stand against it.","In the midst of movement and chaos, keep stillness inside of you.","Success does not consist in never making mistakes but in never making the same one a second time.","I don't want to get to the end of my life and find that I lived just the length of it. I want to have lived the width of it as well.","As we look ahead into the next century, leaders will be those who empower others.","Our greatest fear should not be of failure... but of succeeding at things in life that don't really matter.","Be yourself. Everyone else is already taken.","If you don't design your own life plan, chances are you'll fall into someone else's plan. And guess what they have planned for you? Not much.","But you have to do what you dream of doing even while you're afraid.","To be successful, you must accept all challenges that come your way. You can't just accept the ones you like.","Be patient with yourself. Self-growth is tender; it's holy ground. There's no greater investment.","Many of life's failures are people who did not realize how close they were to success when they gave up.","If you can copy and paste one hundred and one inspirational quotes, you can do anything"]
    await ctx.send(random.choice(quotes))

@bot.command(name='news')
async def news(ctx):
        news_url="https://news.google.com/news/rss"
        Client=urllib.request.urlopen(news_url)
        page=Client.read()
        Client.close()
        soup_page=BeautifulSoup(page,"xml")
        news_list=soup_page.findAll("item")
        num=10
        jar=1
        for news in news_list[:int(num)]:
            if random.randint(jar,num)==jar:
                await ctx.send(news.title.text)
                break
            jar+=1

@bot.command(name='what-is')
async def define(ctx, search):
    req = Request('https://en.wikipedia.org/wiki/'+search)
    webpage = urlopen(req).read().decode()
    soup = BeautifulSoup(webpage, 'lxml')

    for script in soup(["script", "style"]):
        script.extract()

    text = soup.get_text()
    text= text.split('\n')
    for i in range(len(text)):
        if text[i]=='Jump to search': await ctx.send(search.title()+' is '+text[i+1])

@bot.command(name='ramble')
async def ramble(ctx, keyword):
    await ctx.send('Have patience, this may take a while.')
    await ctx.send(random_sentence.ramble(keyword))

@bot.command(name='members')
async def test(ctx):
    members = str(ctx.guild.members)
    members = members.split("' ")
    array=[]
    for i in members:
        if 'name=' in i and 'bot=' not in i:
            person=(i.replace('name=','').replace("'",''))
        if 'bot=' in i:
            x=i.split()
            if not(eval(x[0].replace('bot=',''))): array.append(person[76:])
    await ctx.send("\n".join(array))
            
@bot.command(name='rank')
async def rank(ctx):
    tally=eval(open('tally.txt','r').read())
    index = tally[0].index(str(ctx.author)[:-5])
    sort=sorted(tally[1])
    await ctx.send('Your score: '+str(tally[1][index])+'\nYour are ranked #'+str(len(sort)-sort.index(tally[1][index])))

@bot.command(name='gamble')
async def gamble(ctx, odds):
    tally=eval(open('tally.txt','r').read())
    index = tally[0].index(str(ctx.author)[:-5])
    sort=sorted(tally[1])
    if not(odds.isnumeric()):
        if int(odds)<=1: await ctx.send('Error, parameter must be an integer greater than 1')
    await ctx.send('Rolling a '+str(odds)+' sided dice...')
    time.sleep(1.5)
    if random.randint(1,int(odds))==1:
        await ctx.send('You won!\nYour score is now '+str(tally[1][index])+' x '+odds+' = '+str(tally[1][index]*int(odds)))
        tally[1][index] = int(tally[1][index]*int(odds))
    else:
        await ctx.send('You lost...\nYour score is now '+str(tally[1][index])+' / '+odds+' = '+str(int(tally[1][index]/int(odds))))
        tally[1][index] = int(tally[1][index]/int(odds))
    update = open('tally.txt','w')
    update.write(str(tally))
    update.close()



if __name__ == '__main__':
    proc = Process(target=inputs)
    proc.start()
    bot.run(TOKEN)


