def ramble(keyword):
    import random, re, json
    from collections import defaultdict
    class LString:
        def __init__(self):
                self._total = 0
                self._successors = defaultdict(int)

        def put(self, word):
                self._successors[word] += 1
                self._total += 1

        def get_random(self):
                ran = random.randint(0, self._total - 1)
                for key, value in self._successors.items():
                    if ran < value:
                        return key
                    else:
                        ran -= value

    couple_words = defaultdict(LString)

    def load(phrases):
            # add (encoding='utf8') if it fails
            with open(phrases, 'r') as f:
                for line in f:
                    line = line.split('+')[-1][1:-1]
                    line=line.split('. ')
                    for i in line:
                        add_message(i)
                        
    def add_message(message):
            message = re.sub(r'[^\w\s\']', '', message).lower().strip()
            words = message.split()
            if len(words)>2:
                for i in range(2, len(words)):
                    couple_words[(words[i - 3], words[i - 2], words[i - 1])].put(words[i])
                couple_words[(words[-3], words[-2], words[-1])].put("")

    def generate(keyword):
            result = []
            tries=0
            while (len(result) < 10 or len(result) > 20) and tries<20:
                tries+=1
                result = []
                bank=[]
                for i in list(couple_words.keys()):
                    if keyword in i: bank.append(i)
                try: s = random.choice(bank)
                except IndexError: return 'Sorry, I have nothing to ramble about '+keyword
                result.extend(s)
                while result[-1]:
                    w = couple_words[(result[-3], result[-2], result[-1])].get_random()
                    result.append(w)

            return " ".join(result)

    load("movie_lines.txt")
    return generate(keyword)

