import discord

TOKEN = 'TOKEN'
client = discord.Client()
@client.event
async def on_message(message):
    if message.author == client.user: return
    if '<@!YOUR_ID>' in str(message.content) or '<@YOUR_ID>' in str(message.content): await message.channel.send('Thank you for notifying xand, he will be with you shortly')
    #await message.channel.send(input(message.content))
    
    inputt = open('input.txt','w')
    inputt.write(message.content)
    inputt.close()


client.run(TOKEN)
