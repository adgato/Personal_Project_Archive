ORGINISER INFO:

la
an array for every option of the input index shown in train.txt 	array=[a,b,c,d]		(X)
inside, an array for each option					d    =[i,ii]		
inside, an array for each combination 					i    =[1,2,3]		{Y}
									ii   =[-1,1,2]
hidden
an array for each output 						array=[a,b]		[Z]
inside, an array for each combination 					a    =[i,ii,iii]	{Y}
inside, an array for every backpropagation prediction of la 		i    =[1,-1,1,1]	(X)
									ii   =[-1,-1,1,1]
yy
an array for each output 						array=[a,b]		[Z]
inside, an array for each combination 					a    =[1,-1,1]		{Y}


a very simple example being:

{1 combination}
[2 outputs]
(3 inputs so 7 options)

〔bias + weights for len x〕
|2 always 〔biasweights〕 + xor|

x = ( 〔 {'1'} 〕, 〔 {'2'} 〕, 〔 {'3'} 〕, 〔 {'1'}, {'2'} 〕, 〔 {'1'}, {'3'} 〕, 〔 {'2'}, {'3'} 〕, 〔 {'1'}, {'2'}, {'3'} 〕 )

y = [ { (1, 1, 1, 1, 1, 1, 1) }, { (-1, -1, -1, -1, -1, -1, -1) } ]

o = [ {'1'}, {'-1'} ]


TRAINER INFO:

w = [ ( | 〔1, 1〕, 0 |, | 〔1, 2〕, 0 |, | 〔1, 3〕, 0 |, | 〔2, 0, 0〕, 0 |, | 〔1, 1, 3〕, 0 |, | 〔1, 2, 3〕, 0 |, | 〔1, 1, 2, 3〕, 0 | ),
      ( | 〔1, 1〕, 0 |, | 〔1, 2〕, 0 |, | 〔1, 3〕, 0 |, | 〔2, 0, 0〕, 0 |, | 〔1, 1, 3〕, 0 |, | 〔1, 2, 3〕, 0 |, | 〔1, 1, 2, 3〕, 0 | ) ]

lb
[({0.8807970779778823, 0.5}, [0.9933071490757153, 0.04742587317756678], [0.9999546021312976, 0.0003353501304664781], [0.8807970779778823, 0.8807970779778823], [0.999983298578152, 0.00012339457598623172], [0.9999991684719722, 6.144174602214718e-06], [0.999999694097773, 2.2603242979035746e-06]],
 ({0.8807970779778823, 0.5}, [0.9933071490757153, 0.04742587317756678], [0.9999546021312976, 0.0003353501304664781], [0.9975273768433653, 0.01798620996209156], [0.999983298578152, 0.00012339457598623172], [0.9999991684719722, 6.144174602214718e-06], [0.999999694097773, 2.2603242979035746e-06]]]

an array for each output [2]
inside, an array for each option (7)
inside, an array for each combination {2}
