import glob #line added 18/08/21
if input('Would you like to make a new AI? (y/n) ')=='y':
    import _Orginiser
    import _Trainer
    weights=open('./WeightsData.txt','r').read()
    print('\nAI complete\n')
    name=input('What would you like to call you AI? ')
    newAI=open('./CreatedAI/'+name+'.txt','w')
    newAI.write(weights)
    table=open('OrginiserData.txt','r').readlines()
    newAI.write(table[0])
    newAI.write(table[2])
    newAI.close()
    print('All done!')
while input('\nWould you like to use an AI? (y/n) ')=='y':
    from _Functions import f
    for file in glob.glob('./CreatedAI/*.txt'): print('-',file.replace('./CreatedAI\\','')) #line added 18/08/21 bc back then I was very unhelpful
    weights=open('./CreatedAI/'+input('Which one? ')+'.txt','r').readlines()
    l1w=eval(weights[0].replace('\n',''))
    l2w=eval(weights[1].replace('\n',''))
    names=weights[3].replace('\n','').split()
    while True:
        x=eval(weights[2].replace('\n',''))
        q=[]
        for i in range(int(x[-1][-1])+1): q.append(int(input(names[i]+'? ')))
        for i in range(len(x)):
            for k in range(len(x[i])):
                x[i][k]=q[int(x[i][k])]
        brek=False
        for w in range(len(l1w)):
            h=[]
            for i in range(len(x)):
                h.append(f.sigmoid(f.integration(x[i],l1w[w][i])))
            if input(str(round(f.sigmoid(f.integration(h,l2w[w]))*100))+'% positive for '+str(names[len(q)+w])+' ') == 'break': brek=True #18/08/21 more proof back then I was very unhelpful
        if brek: break
#need some way to find a min and max
#and use that as a bias for results
#to make them more accurate
#formula for ^ below:
'''
100 - 100/(max-min) * (max-num)
'''

#_Learner theory
'''
get the computer to do the best combination
take the actual result
use the best combination and the result and re-learn the ai
the best combination should have improved
'''
