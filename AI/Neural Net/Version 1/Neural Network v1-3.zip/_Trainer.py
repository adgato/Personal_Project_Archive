from _Functions import op, f

info=open('TrainerData.txt','r').readlines()
x=eval(info[0].replace('\n',''))
y=eval(info[1].replace('\n',''))
o=eval(info[2].replace('\n',''))
w=[]
lb=[]
for c in range(len(o)): # [each]
    w.append([])
    lb.append([])
    for a in range(len(x)): # (each)
        xx=[]
        yy=[]
        l=[]
        for b in range(len(x[0][0])): # {each}
            xxx=[]
            for z in x[a]:      #〔each〕
                xxx.append(z[b])
            xx.append(xxx)
            yy.append(y[c][b][a])
        weight=op.perceptron(xx,yy)
        for s in xx: l.append(f.sigmoid(f.integration(s,weight)))
        lb[-1].append(l)
        w[-1].append(weight)
l1w=eval(str(w))
w=[]
for c in range(len(o)): # [each]
    w.append([])
    xx=[]
    l=[]
    for b in range(len(lb[0][0])): # {each}
        xx.append([])
        for a in range(len(lb[0])): # (each)
            xx[-1].append(lb[c][a][b])
    weight=op.perceptron(xx,o[c])
    for s in xx: l.append(f.sigmoid(f.integration(s,weight)))
    w[-1].append(weight)
l2w=eval(str(w))[0]                                                 #################[0]?

table=open('WeightsData.txt','w')
table.write(str(l1w)+'\n')
table.write(str(l2w)+'\n')
table.close()
