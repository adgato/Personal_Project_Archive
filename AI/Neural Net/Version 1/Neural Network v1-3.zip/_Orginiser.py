from itertools import permutations
import math as m, os

num=int(input('How many questions? '))
skip=input('have you the data? ')


if skip!='y':
    rage=[]
    x=[]
    questions=[]
    pos=1
    for i in range(num):
        rage.append([])
        questions.append(input('What is question '+str(i)+'? '))
        rage[i].append(int(input('What is the min value for question '+str(i)+'? ')))
        rage[i].append(int(input('What is the max value for question '+str(i)+'? '))+1)

    for i in range(num): pos*=rage[i][1]-rage[i][0]
    minnum=[]
    maxnum=[]
    for i in range(len(rage)):
        minnum.append(rage[i][0])
        maxnum.append(rage[i][1]-1)
    while minnum!=maxnum:
        if not(0 in minnum):
            x.append(eval(str(minnum)))
        inc=1
        for i in range(len(minnum)):
            minnum[len(minnum)-(i+1)]=minnum[len(minnum)-(i+1)]+inc
            if minnum[len(minnum)-(i+1)]==rage[len(rage)-1-i][1]:
                minnum[len(minnum)-(i+1)]=rage[len(rage)-1-i][0]
                inc=1
            else: inc=0
    x.append(maxnum)

    la=[]
    perm=''
    for i in range(num): perm+=str(i)
    for i in range(len(x[0])+1):
        for l in permutations(perm,i):
            layer=list(''.join(l))
            v=True
            for i in la:
                if not(v): break
                if len(i)==len(layer):
                    count=0
                    for q in layer:
                        if q in i:
                            count+=1
                    if count==len(layer): v=False
            if len(layer)>0 and v: la.append(layer)
            if len(layer)==4: break 
    outputs=[]

numb=int(input('How many outputs? '))

if skip!='y':
    for i in range(numb): outputs.append(input('What does output '+str(i)+' indicate? '))
    print('please fill out the table')
    table=open('OrginiserData.txt','w')
    table.write(str(la)+'\n\n')
    txtqu=[]
    for i in questions: txtqu.append(i)
    for i in outputs: txtqu.append(i)
    print(txtqu)
    for i in range(len(txtqu)):
        while len(str(txtqu[i]))<2: txtqu[i]=' '+txtqu[i]
        txtqu[i]=str(txtqu[i])[:2]
    table.write('    '.join(txtqu)+'\n\n')
    for i in x:
        line=''
        for j in i:
            if str(j)=='-1': line+=str(j)+'    '
            else: line+=' '+str(j)+'    '
        table.write(line+'\n')
    table.close()
    os.system('OrginiserData.txt')
    input('done? ')


table=open('OrginiserData.txt','r')
yy=[]
x=[]
c=0


'''making of x and yy'''
for i in range(numb): yy.append([])
for i in table.readlines():
    c+=1
    if c==1:
        la=eval(i)
    if c>4:
        line=i.split()
        appended=False
        for i in range(num,len(line)):
            yy[i-num].append(int(line[i]))
            appended=True
        if appended:
            x.append([])
            for i in range(num): x[len(x)-1].append(int(line[i]))


'''making of xs'''
xl=[]
for i in x: xl.append(len(i))
xs=[]
for i in range(max(xl)): xs.append([])
for i in range(len(x)):
    for q in range(len(x[i])): xs[q].append(x[i][q])

'''making of la'''       
for j in range(len(la)):
    for i in range(len(la[j])):
        la[j][i]=xs[int(la[j][i])]

'''making of hidden'''
hidden=[]
for k in range(len(yy)):
    hidden.append([])
    for q in range(len(la[0][0])):
        hd=eval(str(la))
        for i in range(len(la)):
            total=0
            for j in range(len(la[i])):
                total+=int(la[i][j][q])
            if (total>0 and int(yy[k][q])>0) or (total<0 and int(yy[k][q])<0): hd[i]=1
            else: hd[i]=-1
            #print(la[i][:][q],total,hd[i],yy[k][q])
        hidden[k].append(hd)

table=open('TrainerData.txt','w')
table.write(str(la)+'\n')
table.write(str(hidden)+'\n')
table.write(str(yy)+'\n')
table.close()
        
    

    

