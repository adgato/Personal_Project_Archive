import math as m

class f:
    
    def integration(x,weights):
        xdotw=0
        if weights[1]==1: x=f.xor(x)
        for i in range(len(weights[0])-1): xdotw+=x[i]*weights[0][i+1]
        return xdotw+weights[0][0]
        
    def sigmoid(v): return 1/(1+m.exp(-v))

    def update(x,w,b,i,y):
        wt=[]
        for q in range(len(x[0])): wt.append(w[len(w)-1][q]+y[i]*x[i][q])
        bt=b[len(b)-1]+y[i]
        tt=[wt,bt]
        return tt

    def check(x,w,b,i):
        wt=[]
        for q in range(len(x[0])): wt.append(w[len(w)-1][q]*x[i][q])
        return sum(wt)+b[len(b)-1]

    def xor(x):
        try:
            nx=[]
            for i in range(len(x)):
                dif = x[i][0]
                for q in range(len(x[i])):
                    if q!=0: dif -= x[i][q]
                nx.append([int((dif**2)**0.5)])
        except Exception as e:
            nx=[x[0]**2]
        return nx

class op:

     def perceptron(x,y):
         axor=0
         unsucess=0
         while unsucess<2:
               w=[[]]
               b=[0]
               for i in range(len(x[0])): w[0].append(0)
               correct=0
               tries=0
               unsucess+=1
               while correct<len(x) and tries<40:
                    tries+=1
                    for i in range(len(x)):
                        if (f.check(x,w,b,i)<f.sigmoid(f.check(x,w,b,i)) and y[i]<0) or (f.check(x,w,b,i)>f.sigmoid(f.check(x,w,b,i)) and y[i]>0): correct+=1
                        else:
                            correct=0
                            new=f.update(x,w,b,i,y)
                            w.append(new[0])
                            b.append(new[1])
               if not(correct<len(x)):
                   failure=False
                   break
               if unsucess==1:
                   axor=1
                   nx=eval(str(x))
                   x=f.xor(x)
               if unsucess==2 and axor==1:
                   unsucess=1
                   axor=0
                   x=nx
                   continue
               failure=True      
         if failure: print('best fit')
         w[len(w)-1].insert(0,b[len(b)-1])
         output=w[len(w)-1]
         return [output,axor]
            


