from camera import arCamera
from hand_detection import DetectHand
from UI import Interface
import os, datetime

def screenshot(filename):
	os.system('raspi2png; convert snapshot.png -crop 960x720+960+340 -resize 200 ' + filename)

camera  = arCamera()
handNet = DetectHand()
UI      = Interface()

camera.Enable()

try:
	while True:
		if UI.photoState == 'Running': 
			shotName = datetime.datetime.now().strftime('%H_%M_%S.png')
		else: shotName = 'cropped.png'
		
		screenshot(shotName)
		images  = handNet.ProcessImg(shotName)
		outputs = handNet.propagate(images)
		outputs = [float(output) if float(output) >= 0.5 else 0 for output in outputs]
		
		
		UI.ClearFrame()
		for i, certainty in enumerate(outputs):
			UI.FillFrame(i, certainty)

		UI.UpdateText()
		UI.Update()
except Exception: 
	camera.Disable()
#in future use add gyroscopic funtionality for enhanced experience
