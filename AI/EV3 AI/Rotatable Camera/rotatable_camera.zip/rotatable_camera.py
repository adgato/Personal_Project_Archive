#'hack' the YI-home device so snapshots can be grabbed via url:
'https://github.com/TheCrypt0/yi-hack-v4'
#use imageai to detect human position in snapshots
#get the ev3 to work remotely:
'https://ev3dev-lang.readthedocs.io/projects/python-ev3dev/en/ev3dev-jessie/rpyc.html'

from imageai.Detection import ObjectDetection
import os, time
import requests
import urllib.request
import cv2
import rpyc

conn = rpyc.classic.connect('ev3dev') # host name or IP address of the EV3
ev3 = conn.modules['ev3dev.ev3']      # import ev3dev.ev3 remotely
Y = ev3.LargeMotor('outB')
X = ev3.MediumMotor('outA')

Yrot = 0
Xrot = 0

current_directory = os.getcwd()

detector = ObjectDetection()
detector.setModelTypeAsTinyYOLOv3()
detector.setModelPath(os.path.join(current_directory , "yolo-tiny.h5"))
detector.loadModel(detection_speed="fastest")

print('Model loaded')

while True:

    urllib.request.urlretrieve("http://192.168.0.33:8080/cgi-bin/snapshot.sh?res=low&watermark=no", "snapshot.jpg")

    detections = detector.detectObjectsFromImage(
        custom_objects=detector.CustomObjects(person=True),
        input_image=os.path.join(current_directory , "snapshot.jpg"),
        output_image_path=os.path.join(current_directory , "output.jpg"),
        minimum_percentage_probability=5
    )

    image = cv2.imread("output.jpg")
    
    if detections:  
        points = detections[0]["box_points"]
        x = (points[0] + points[2]) // 2
        y = int((points[1] + points[3]) * 0.35) # * 0.35 rather than // 2 so that camera turns more towards human head (creepier that way :)
        h, w = image.shape[:2]
        cv2.rectangle(image, (x-1, y+1), (x+1, y-1), (255, 0, 0), 3)
        image = cv2.line(image, (x, y), (w//2, h//2), (255, 0, 0), 2)
        
        if -90 < Yrot + int(65*(w/2-x)/w) < 90:
            Y.run_to_rel_pos(position_sp=int(65*(w/2-x)/w), speed_sp=100)
            Yrot += int(65*(w/2-x)/w)
        if 0 <= Xrot + int(35*(h/2-y)/h) < 90:
            X.run_to_rel_pos(position_sp=int(35*(h/2-y)/h), speed_sp=100)
            Xrot += int(35*(h/2-y)/h)
        
    cv2.destroyAllWindows()
    cv2.imshow('image',image)
    cv2.waitKey(1)

    




