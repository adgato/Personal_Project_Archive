import pyaudio
import struct
import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

pa       = pyaudio.PyAudio()
FORMAT   = pyaudio.paInt16
CHANNELS = 1
RATE     = 44100
CHUNK    = 1024

for ii in range(pa.get_device_count()):
   if 'VoiceMeeter Output' in pa.get_device_info_by_index(ii)['name']:
       index = ii
       break

def peak_detect(data):
    max_val = np.amax(abs(data))
    peak_ndx = np.where(data == max_val)
    if len(peak_ndx[0]) == 0:  # if nothing found then the max must be negative
        peak_ndx = np.where(data == -max_val)
    return peak_ndx


def smoothData(y, box_pts):
    box = np.ones(box_pts)/box_pts
    y_smooth = np.convolve(y, box, mode='same')
    return y_smooth
    
stream = pa.open(format = FORMAT,
                 channels = CHANNELS,
                 rate = RATE,
                 input = True,
                 input_device_index = index,
                 frames_per_buffer = CHUNK)

fig, (ax0, ax1, ax2) = plt.subplots(1, 3, figsize=(14,6))

x = np.arange(0, 2 * CHUNK, 2)
line0a, = ax0.plot(x, np.zeros(CHUNK))
line0b, = ax0.plot(x, np.zeros(CHUNK))
line0c, = ax0.plot(x, np.zeros(CHUNK))

data1 = np.zeros(50000)
x = np.arange(data1.size)
line1, = ax1.plot(data1, x)
line1.set_color('orange')

t = np.arange(CHUNK)
freq = np.fft.fftfreq(t.size) * RATE
rearrange = freq.argsort()
freq = freq[rearrange]
sp = np.fft.fft(np.arange(CHUNK))
line2, = ax2.plot(freq, abs(sp.real))
line2.set_color('red')

ax0.set_ylim(-50000, 50000)
ax0.set_xlim(0, CHUNK)

ax1.set_xlim(-40000, 40000)
ax1.set_ylim(0, 50000)

ax2.set_ylim(0, 1.5) #200000
ax2.set_xlim(np.min(freq), np.max(freq))


while True:

    data = stream.read(CHUNK, exception_on_overflow = False)
    data = np.frombuffer(data, np.int16)

    data0a = smoothData(data, 200)
    data0b = smoothData(data - data0a, 25)
    data0c = smoothData(data - data0a - data0b, 10)

    data1 = np.append(data1[data.size:], data)

    sp = np.fft.fft(data)
    sp = 1 / abs(sp.real)
    sp = sp[rearrange]
    
    line0a.set_ydata(data0a - 30000)
    line0b.set_ydata(data0b)
    line0c.set_ydata(data0c + 30000)

    line1.set_xdata(data1)

    line2.set_data(freq, sp)

    fig.canvas.draw_idle()
    plt.pause(0.0001)

